package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Usuario;
import util.ConnectionFactory;
import util.exception.ErroSistema;

public class UsuarioDAO implements CrudDAO<Usuario> {

    @Override
    public void salvar(Usuario usuario) throws ErroSistema {
        try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps;
            if (usuario.getIdusuario() == null) {
                ps = conexao.prepareStatement("INSERT INTO `usuario`(`nome`,`senha`)VALUES (?,?);");
            } else {
                ps = conexao.prepareStatement("update usuario set nome=?, senha=? where idusuario=?");
                ps.setInt(3, usuario.getIdusuario());
            }
            ps.setString(1, usuario.getNome());
            ps.setString(2, usuario.getSenha());
            ps.execute();
            ConnectionFactory.closeConnection();
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao tentar salvar!", ex);
        }
    }

    @Override
    public void deletar(Usuario usuario) throws ErroSistema {
        try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps = conexao.prepareStatement("delete from usuario where idusuario = ?");
            ps.setInt(1, usuario.getIdusuario());
            ps.execute();
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao deletar o item!", ex);
        }
    }

    @Override
    public List<Usuario> buscar() throws ErroSistema {
        try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps = conexao.prepareStatement("select * from usuario");
            ResultSet resultSet = ps.executeQuery();
            List<Usuario> usuarios = new ArrayList<>();
            while(resultSet.next()){
                Usuario usuario = new Usuario();
                usuario.setIdusuario(resultSet.getInt("idusuario"));
                usuario.setNome(resultSet.getString("nome"));
                usuario.setSenha(resultSet.getString("senha"));
                usuarios.add(usuario);
            }            
            ConnectionFactory.closeConnection();
            return usuarios;
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao buscar os itens!", ex);
        }
    }
    
    public List<Usuario> buscarUsuario(String nome) throws ErroSistema {
        try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps = conexao.prepareStatement("select * from usuario where nome = " + nome );
            ResultSet resultSet = ps.executeQuery();
            List<Usuario> usuarios = new ArrayList<>();
            while(resultSet.next()){
                Usuario usuario = new Usuario();
                usuario.setNome(resultSet.getString("nome"));
                usuarios.add(usuario);
            }            
            ConnectionFactory.closeConnection();
            return usuarios;
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao buscar os itens!", ex);
        }
    }
        
    public List<Usuario> buscarSenha(String senha) throws ErroSistema {
        try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps = conexao.prepareStatement("select * from usuario where nome = " + senha );
            ResultSet resultSet = ps.executeQuery();
            List<Usuario> usuarios = new ArrayList<>();
            while(resultSet.next()){
                Usuario usuario = new Usuario();
                usuario.setNome(resultSet.getString("senha"));
                usuarios.add(usuario);
            }            
            ConnectionFactory.closeConnection();
            return usuarios;
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao buscar os itens!", ex);
        }
    }

}
