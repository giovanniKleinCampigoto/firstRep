package dao;

import java.util.List;
import util.exception.ErroSistema;

public interface CrudDAO<E> { //E representa a entidade
    
    public void salvar(E entidade) throws ErroSistema;    
    public void deletar(E entidade) throws ErroSistema;
    public List<E> buscar () throws ErroSistema;
    
}
