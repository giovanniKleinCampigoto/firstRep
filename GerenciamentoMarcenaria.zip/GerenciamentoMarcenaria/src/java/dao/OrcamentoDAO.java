package dao;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Connection;
import java.util.List;
import model.Orcamento;
import util.ConnectionFactory;
import util.exception.ErroSistema;

public class OrcamentoDAO implements CrudDAO<Orcamento>{
    

    @Override
    public void salvar(Orcamento orcamento) throws ErroSistema {
        try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps;
            if (orcamento.getIdorcamento() == null) {
                ps = conexao.prepareStatement("INSERT INTO `orcamento` (`nome`,`descricao`,`quantidade`,`valor`)VALUES (?,?,?,?);");
            } else {
                ps = conexao.prepareStatement("update orcamento set nome=?, descricao=?, quantidade=?, valor=? where idorcamento=?");
                ps.setInt(5, orcamento.getIdorcamento());
            }
            ps.setString(1, orcamento.getNome());
            ps.setString(2, orcamento.getDescrição());
            ps.setInt(3, orcamento.getQuantidade());
            ps.setInt(4, orcamento.getValor());            
            ps.execute();
            ConnectionFactory.closeConnection();
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao tentar salvar!", ex);
        }
        
    }

    @Override
    public void deletar(Orcamento orcamento) throws ErroSistema {
        try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps = conexao.prepareStatement("delete from orcamento where idorcamento = ?");
            ps.setInt(1, orcamento.getIdorcamento());
            ps.execute();
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao deletar o item!", ex);
        }

    }
   

    @Override
    public List<Orcamento> buscar() throws ErroSistema {
         try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps = conexao.prepareStatement("select * from orcamento");
            ResultSet resultSet = ps.executeQuery();
            List<Orcamento> orcamentos = new ArrayList<>();
            while(resultSet.next()){
                Orcamento orcamento = new Orcamento();
                orcamento.setIdorcamento(resultSet.getInt("idorcamento"));
                orcamento.setNome(resultSet.getString("nome"));
                orcamento.setDescrição(resultSet.getString("descricao"));
                orcamento.setQuantidade(resultSet.getInt("quantidade"));
                orcamento.setValor(resultSet.getInt("valor"));                
                orcamentos.add(orcamento);
            }            
            ConnectionFactory.closeConnection();
            return orcamentos;
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao buscar os itens!", ex);
        } 
    }
    
}
