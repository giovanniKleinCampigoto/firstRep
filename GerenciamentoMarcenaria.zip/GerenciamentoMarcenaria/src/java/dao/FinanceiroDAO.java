package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Financeiro;
import util.ConnectionFactory;
import util.exception.ErroSistema;

public class FinanceiroDAO implements CrudDAO<Financeiro> {

    @Override
    public void salvar(Financeiro financeiro) throws ErroSistema {
        try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps;
            if (financeiro.getIdFinanceiro() == null) {
                ps = conexao.prepareStatement("INSERT INTO `financeiro`(`data`,`valor`,`descricao`)VALUES(?,?,?);");
            } else {
                ps = conexao.prepareStatement("update financeiro set data=?, valor=?, descricao=? where idfinanceiro=?");
                ps.setInt(4, financeiro.getIdFinanceiro());
            }
            ps.setDate(1, new Date(financeiro.getData().getTime()));
            ps.setInt(2, financeiro.getValor());
            ps.setString(3, financeiro.getDescrição());
            ps.execute();
            ConnectionFactory.closeConnection();
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao tentar salvar!", ex);
        }
    }

    @Override
    public void deletar(Financeiro financeiro) throws ErroSistema {
        try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps = conexao.prepareStatement("delete from financeiro where idfinanceiro = ?");
            ps.setInt(1, financeiro.getIdFinanceiro());
            ps.execute();
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao deletar o item!", ex);
        }
    }

    @Override
    public List<Financeiro> buscar() throws ErroSistema {
        try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps = conexao.prepareStatement("select * from financeiro");
            ResultSet resultSet = ps.executeQuery();
            List<Financeiro> financeiros = new ArrayList<>();
            while (resultSet.next()) {
                Financeiro financeiro = new Financeiro();
                financeiro.setIdFinanceiro(resultSet.getInt("idfinanceiro"));
                financeiro.setData(resultSet.getDate("data"));
                financeiro.setValor(resultSet.getInt("valor"));
                financeiro.setDescrição(resultSet.getString("descricao"));
                financeiros.add(financeiro);
            }
            ConnectionFactory.closeConnection();
            return financeiros;
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao buscar os itens!", ex);
        }
    }

}
