package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Item;
import util.ConnectionFactory;
import util.exception.ErroSistema;

public class ItemDAO implements CrudDAO<Item>{
   
    @Override
    public void salvar(Item item) throws ErroSistema {
        try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps;
            if(item.getIditem() == null){
                ps = conexao.prepareStatement("INSERT INTO `item`(`nome`,`tipo`,`dimensão`,`valor`,`quantidade`,`data`)VALUES(?,?,?,?,?,?);");
            }else{
                ps = conexao.prepareStatement("update item set nome=?, tipo=?,dimensão=?, valor=?, quantidade=?, data=? where iditem=?");
                ps.setInt(7, item.getIditem());
            }            
            ps.setString(1, item.getNome());
            ps.setString(2, item.getTipo());
            ps.setString(3, item.getDimensão());
            ps.setInt(4, item.getValor());
            ps.setInt(5, item.getQuantidade());
            ps.setDate(6, new Date(item.getData().getTime()));
            ps.execute();
            ConnectionFactory.closeConnection();
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao tentar salver!", ex);
        }
    }
    
    @Override
    public List<Item> buscar() throws ErroSistema{
        try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps = conexao.prepareStatement("select * from item");
            ResultSet resultSet = ps.executeQuery();
            List<Item> itens = new ArrayList<>();
            while(resultSet.next()){
                Item item = new Item();
                item.setIditem(resultSet.getInt("iditem"));
                item.setNome(resultSet.getString("nome"));
                item.setTipo(resultSet.getString("tipo"));
                item.setDimensão(resultSet.getString("dimensão"));
                item.setValor(resultSet.getInt("valor"));
                item.setQuantidade(resultSet.getInt("quantidade"));
                item.setData(resultSet.getDate("data"));
                itens.add(item);
            }            
            ConnectionFactory.closeConnection();
            return itens;
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao buscar os itens!", ex);
        }        
    }
    
    @Override
    public void deletar(Item item) throws ErroSistema{
        try {
            Connection conexao = ConnectionFactory.getConexao();
            PreparedStatement ps = conexao.prepareStatement("delete from item where iditem = ?");
            ps.setInt(1, item.getIditem());
            ps.execute();
        } catch (SQLException ex) {
            throw new ErroSistema("Erro ao deletar o item!", ex);
        }
    }


}
