package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import util.exception.ErroSistema;

public class ConnectionFactory {
    
    private static Connection conexao;
    private static final String URL_CONEXAO = "jdbc:mysql://localhost/gerenciamento-marcenaria";
    private static final String USUARIO = "root";
    private static final String SENHA = "123";

    public static Connection getConexao() throws ErroSistema {
        if(conexao == null){
            try {
                Class.forName("com.mysql.jdbc.Driver");
                try {
                    conexao = DriverManager.getConnection(URL_CONEXAO, USUARIO, SENHA);
                } catch (SQLException ex) {
                    throw new ErroSistema("Não foi possível contectar ao banco de dados!", ex);
                }
            } catch (ClassNotFoundException ex) {
                throw new ErroSistema("O driver do banco de dados não foi encontrado!", ex);
            }
        }
        return conexao;
    }
    
    public static void closeConnection() throws ErroSistema {
        if(conexao != null){
            try {
                conexao.close();
                conexao = null;
            } catch (SQLException ex) {
                throw new ErroSistema("Erro ao fechar conexão com o banco de dados!", ex);
            }
        }
    }
    
    
    
}
