package controller;

import dao.FinanceiroDAO;
import dao.ItemDAO;
import dao.OrcamentoDAO;
import java.io.Serializable;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import model.Financeiro;
import model.Item;
import model.Orcamento;
import util.exception.ErroSistema;

@SessionScoped
@ManagedBean
public class FinanceiroController implements Serializable{

    //Itens a serem somados
    private ItemDAO item = new ItemDAO();
    private OrcamentoDAO orcamento = new OrcamentoDAO();
    private FinanceiroDAO financeiro = new FinanceiroDAO();

    private ArrayList<Item> itemA = new ArrayList<>();
    private ArrayList<Orcamento> orcamentoA = new ArrayList<>();
    private ArrayList<Financeiro> financeiroA = new ArrayList<>();

    private int valorTotal;
    
    public void pegarTotal() throws ErroSistema {

        itemA.addAll(item.buscar());
        orcamentoA.addAll(orcamento.buscar());
        financeiroA.addAll(financeiro.buscar());

        valorTotal = 0;

        for (Item item1 : itemA) {
            valorTotal += item1.getValor();
        }

        for (Orcamento orcamento1 : orcamentoA) {
            valorTotal += orcamento1.getValor();
        }

        for (Financeiro financeiro1 : financeiroA) {
           valorTotal += financeiro1.getValor();           
        }

        itemA.clear();
        orcamentoA.clear();
        financeiroA.clear();

    }

    public int getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(int valorTotal) {
        this.valorTotal = valorTotal;
    }

}
