package controller;

import dao.FinanceiroDAO;
import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import model.Financeiro;

@SessionScoped
@ManagedBean
public class FinanceiroBean extends CrudBean<Financeiro, FinanceiroDAO> implements Serializable{

    private FinanceiroDAO financeiroDAO;

    @Override
    public FinanceiroDAO getDao() {
        if (financeiroDAO == null) {
            financeiroDAO = new FinanceiroDAO();
        }
        return financeiroDAO;
    }

    @Override
    public Financeiro criarNovaEntidade() {
        return new Financeiro();
    }

}
