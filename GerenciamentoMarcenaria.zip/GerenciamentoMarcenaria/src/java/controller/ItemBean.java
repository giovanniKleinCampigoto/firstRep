package controller;

import dao.ItemDAO;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import model.Item;

@SessionScoped
@ManagedBean
public class ItemBean extends CrudBean<Item,ItemDAO>{

    private ItemDAO itemDAO;
    
    
    @Override
    public ItemDAO getDao() {
        if(itemDAO == null){
            itemDAO = new ItemDAO();
        }
        return itemDAO;
    }

    @Override
    public Item criarNovaEntidade() {
        return new Item();
    }
    
   

}

