package controller;

import dao.CrudDAO;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import model.Usuario;
import util.exception.ErroSistema;

public abstract class CrudBean<E, D extends CrudDAO>{
    
    private String estadoTela = "buscar"; //Insere, Edita e Busca
    
    private E entidade;
    private List<E> entidades;
    private List<E> entidadesSelecionadas;
    
    public void novo(){
        entidade = criarNovaEntidade();
        mudarParaInseri();
    }
    
    public void salvar(){
        try {
            getDao().salvar(entidade);
            entidade = criarNovaEntidade();
            adicionarMensagem("Salvo com sucesso!", FacesMessage.SEVERITY_INFO);
            entidades = getDao().buscar();
            mudarParaBusca();
        } catch (ErroSistema ex) {
            Logger.getLogger(CrudBean.class.getName()).log(Level.SEVERE, null, ex);
            adicionarMensagem(ex.getMessage(), FacesMessage.SEVERITY_ERROR);
        }
    }
    
    public void editar(E entidade){
        this.entidade = entidade;
        mudarParaEdita();
    }
    
    public void deletar(E entidade){
        try {
            getDao().deletar(entidade);
            entidades.remove(entidade);
            adicionarMensagem("Deletado com sucesso!", FacesMessage.SEVERITY_INFO);
        } catch (ErroSistema ex) {
            Logger.getLogger(CrudBean.class.getName()).log(Level.SEVERE, null, ex);
            adicionarMensagem(ex.getMessage(), FacesMessage.SEVERITY_ERROR);
        }
    }
    
    public void buscar(){
        if(isBusca() == false){
            mudarParaBusca();
            return;
        }
        try {
            entidades = getDao().buscar();
            if(entidades == null || entidades.size() < 1){
                adicionarMensagem("Não existe nenhum dado cadastrado!", FacesMessage.SEVERITY_WARN);
            }
        } catch (ErroSistema ex) {
            Logger.getLogger(CrudBean.class.getName()).log(Level.SEVERE, null, ex);
            adicionarMensagem(ex.getMessage(), FacesMessage.SEVERITY_ERROR);
        }
    }
    
    public void adicionarMensagem(String mensagem, FacesMessage.Severity tipoErro){
        FacesMessage fm = new FacesMessage(tipoErro, mensagem, null);
        FacesContext.getCurrentInstance().addMessage(null, fm);
    }

    public E getEntidade() {
        return entidade;
    }

    public List<E> getEntidades() {
        return entidades;
    }

    public void setEntidade(E entidade) {
        this.entidade = entidade;
    }

    public void setEntidades(List<E> entidades) {
        this.entidades = entidades;
    }

    public List<E> getEntidadesSelecionadas() {
        return entidadesSelecionadas;
    }

    public void setEntidadesSelecionadas(List<E> entidadesSelecionadas) {
        this.entidadesSelecionadas = entidadesSelecionadas;
    }
    
    public abstract D getDao();
    public abstract E criarNovaEntidade();
    
    public boolean isInseri(){
        return "inserir".equals(estadoTela);
    }    
    public boolean isEdita(){
        return "editar".equals(estadoTela);
    }    
    public boolean isBusca(){
        return "buscar".equals(estadoTela);
    }    
    public void mudarParaInseri(){
        estadoTela = "inserir";
    }    
    public void mudarParaEdita(){
        estadoTela = "editar";
    }    
    public void mudarParaBusca(){
        estadoTela = "buscar";
    }
}
