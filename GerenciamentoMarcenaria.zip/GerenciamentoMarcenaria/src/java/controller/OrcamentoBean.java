
package controller;

import dao.OrcamentoDAO;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import model.Orcamento;


@SessionScoped
@ManagedBean
public class OrcamentoBean extends CrudBean<Orcamento,OrcamentoDAO> {

    private OrcamentoDAO orcamentoDAO;
    
    @Override
    public OrcamentoDAO getDao() {
        if(orcamentoDAO == null){
            orcamentoDAO = new OrcamentoDAO();
        }
        return orcamentoDAO;
    }

    @Override
    public Orcamento criarNovaEntidade() {
        return new Orcamento();
    }
    
}
