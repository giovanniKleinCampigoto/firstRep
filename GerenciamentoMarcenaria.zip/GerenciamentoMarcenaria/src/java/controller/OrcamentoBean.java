
package controller;

import dao.OrcamentoDAO;
import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import model.Orcamento;


@SessionScoped
@ManagedBean
public class OrcamentoBean extends CrudBean<Orcamento,OrcamentoDAO> implements Serializable {

    private OrcamentoDAO orcamentoDAO;
    
    @Override
    public OrcamentoDAO getDao() {
        if(orcamentoDAO == null){
            orcamentoDAO = new OrcamentoDAO();
        }
        return orcamentoDAO;
    }

    @Override
    public Orcamento criarNovaEntidade() {
        return new Orcamento();
    }
    
}
