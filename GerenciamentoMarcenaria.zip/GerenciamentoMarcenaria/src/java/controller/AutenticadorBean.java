package controller;

import dao.UsuarioDAO;
import java.io.Serializable;
import java.util.ArrayList;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import model.Usuario;
import util.FacesUtil;

import util.SessionUtil;
import util.exception.ErroSistema;

@SessionScoped
@ManagedBean
public class AutenticadorBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private String nome;
    private String senha;
    private boolean isLogado = false;
    UsuarioDAO usuario = new UsuarioDAO();
    ArrayList<Usuario> usuarios = new ArrayList<>();

    public String autentica() throws ErroSistema {
        usuarios.addAll(usuario.buscar());

        for (Usuario usuario1 : usuarios) {
            if (usuario1.getNome().equals(this.nome) && usuario1.getSenha().equals(this.senha)) {

                Object b = new Object();

                isLogado = true;

                SessionUtil.setParam("USUARIOLogado", b);

                return "/index.jsf?faces-redirect=true";
            }
        }

        if (nome.equals("admin") && senha.equals("admin")) {
            Object b = new Object();

            isLogado = true;

            SessionUtil.setParam("USUARIOLogado", b);

            return "/index.jsf?faces-redirect=true";
        } else {
            FacesUtil.addErrorMessage("Senha ou nome incorreto!");
            return null;
        }

    }

    public String registraSaida() {

        SessionUtil.remove("USUARIOLogado");

        usuarios.clear();

        this.nome = "";

        this.senha = "";

        isLogado = false;

        return "/login?faces-redirect=true";
    }

    public String getSenha() {
        return senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public boolean isIsLogado() {
        return isLogado;
    }

    public void setIsLogado(boolean isLogado) {
        this.isLogado = isLogado;
    }

}
