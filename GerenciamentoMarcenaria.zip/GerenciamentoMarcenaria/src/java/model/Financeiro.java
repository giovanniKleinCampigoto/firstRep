
package model;

import java.util.Date;
import java.util.Objects;

public class Financeiro {
    private Integer IdFinanceiro;
    private Integer valor;
    private Date data;
    private String Descrição;

    public Integer getIdFinanceiro() {
        return IdFinanceiro;
    }

    public void setIdFinanceiro(Integer IdFinanceiro) {
        this.IdFinanceiro = IdFinanceiro;
    }

    public Integer getValor() {
        return valor;
    }

    public void setValor(Integer valor) {
        this.valor = valor;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public String getDescrição() {
        return Descrição;
    }

    public void setDescrição(String Descrição) {
        this.Descrição = Descrição;
    }
    
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 37 * hash + Objects.hashCode(this.IdFinanceiro);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Financeiro other = (Financeiro) obj;
        if (!Objects.equals(this.IdFinanceiro, other.IdFinanceiro)) {
            return false;
        }
        return true;
    }
    
}
